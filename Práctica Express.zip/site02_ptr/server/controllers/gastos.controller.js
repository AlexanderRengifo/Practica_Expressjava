const Gasto = require('../models/gastos');
const express = require('express');
const router = express.Router();
const gastosController = {};

router.get('/', (req, res) => {
  res.json({ status: 'API works' });
});

gastosController.getGastos = async (req, res) => {
  try {
    const gastos = await Gasto.find();
    res.json(gastos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

gastosController.createGastos = async (req, res) => {
  try {
    const gasto = new Gasto(req.body);
    console.log(gasto);
    await gasto.save();
    res.json({ status: 'Gasto guardado' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

gastosController.getGasto = async (req, res) => {
  try {
    const gasto = await Gasto.findById(req.params.id);
    res.json(gasto);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

gastosController.editGasto = async (req, res) => {
  try {
    const { id } = req.params;
    const gasto = {
      tipo: req.body.tipo,
      ruc: req.body.ruc,
      empresa: req.body.empresa,
      monto: req.body.monto
    };
    await Gasto.findByIdAndUpdate(id, { $set: gasto }, { new: true });
    res.json({ status: 'Gasto actualizado' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

gastosController.deleteGasto = async (req, res) => {
  try {
    await Gasto.findByIdAndRemove(req.params.id);
    res.json({ status: 'Gasto borrado' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

gastosController.getGastosByTipo = async (req, res) => {
  try {
    const tipo = req.params.tipo;
    const gastos = await Gasto.find({ tipo: tipo });
    res.json(gastos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = gastosController;




